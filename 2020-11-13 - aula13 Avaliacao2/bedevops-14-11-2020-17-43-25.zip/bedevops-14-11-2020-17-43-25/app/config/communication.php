<?php 
return[
    'host' => "bedevops.ckqq54vdwjyo.us-east-1.rds.amazonaws.com",
    'name' => "bedevops_communication",
    'user' => "bedevops",
    'pass' => "Admin1996!",
    'type' => "mysql",
    'prep' => "1",
    'slog' => "SystemSqlLogService"
];