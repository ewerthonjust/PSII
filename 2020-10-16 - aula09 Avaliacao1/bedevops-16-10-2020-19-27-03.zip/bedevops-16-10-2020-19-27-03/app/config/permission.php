<?php 
return[
    'host' => "bedevops.cmwrssojrepd.sa-east-1.rds.amazonaws.com",
    'name' => "bedevops_permission",
    'user' => "admin",
    'pass' => "Admin1996!",
    'type' => "mysql",
    'prep' => "1",
    'slog' => "SystemSqlLogService"
];